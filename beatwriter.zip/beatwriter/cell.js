// cell.js

class Cell {
  constructor(uniqueId, syllable = '', isCandidate = false) {
    this.uniqueId = uniqueId;
    this.syllable = syllable;
    this.isCandidate = isCandidate;
  }

  // Other methods for the Cell class can be added here, if needed.
}

// Export the Cell class (optional, since you mentioned no imports/exports)
// module.exports = Cell;
